package com.example.pakque

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
