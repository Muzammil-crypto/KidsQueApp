# path\_provider\_windows

The Windows implementation of [`path_provider`][1].

## Usage

This package is [endorsed][2], which means you can simply use `path_provider`
normally. This package will be automatically included in your app when you do.

[1]: https://pub.dev/packages/path_provider
[2]: https://flutter.dev/docs/development/packages-and-plugins/developing-packages#endorsed-federated-plugin
