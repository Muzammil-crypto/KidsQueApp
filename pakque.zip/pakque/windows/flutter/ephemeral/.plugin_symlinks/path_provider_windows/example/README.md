# path_provider_windows_example

Demonstrates how to use the path_provider_windows plugin.
