# PakQue Kids

PakQue Kids App.

PakQueKId is an interacting app for kids to learn about Pak history, culture, places, food etc. in a fun way.
It is designed for kids with a lot of enjoying features like Text to speech feature, Map Integration, Category wise Quizzes and Performance Chart, 
History timeline and beautiful design etc. As far as my role is concerned,
I have done all the frontend of the app using Flutter as tech tool and the STRAPI as a backend.
