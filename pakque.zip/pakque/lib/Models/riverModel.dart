class RiverModel {
  String? title;
  String? description;
  String? videoLink;
  List<String> images = [];

  RiverModel();
}
