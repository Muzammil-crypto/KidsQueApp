class HistoryModel {
  String? title;
  String? description;
  String? videoLink;
  String images = "";
  HistoryModel(this.title, this.description, this.videoLink);
}
