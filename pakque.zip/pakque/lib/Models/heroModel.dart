class HeroModel {
  String? title;
  String? duration;
  String? description;
  String? image;
  HeroModel();
}
