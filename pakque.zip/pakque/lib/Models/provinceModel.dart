class RiverModel {
  String title;
  String description;
  String videoLink;
  List<String> images = [];

  RiverModel(this.title, this.description, this.videoLink);
}
