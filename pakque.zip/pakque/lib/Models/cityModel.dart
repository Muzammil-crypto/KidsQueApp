class CityModel {
  String? title;
  String? description;
  String? videoLink;
  List<String> images = [];

  CityModel();
}
