class KidData {
  final String topic;
  final int Marks;

  KidData(this.topic, this.Marks);
}
