import 'package:sign_in_interface/Quiz/lib/models/quiz.dart';

class QuizResult {
  Quiz quiz;
  double totalCorrect;
  QuizResult(this.quiz, this.totalCorrect);
}
