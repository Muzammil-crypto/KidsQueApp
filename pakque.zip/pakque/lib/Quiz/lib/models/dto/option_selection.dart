class OptionSelection {
  bool isSelected;
  String optionText;
  OptionSelection(this.optionText, this.isSelected);
}
